import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createTestContext(role: "user" | "admin" = "user"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Resources API", () => {
  it("returns free resources for all users", async () => {
    const ctx = createTestContext("user");
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.resources.getByAccessLevel("free");
    expect(Array.isArray(result)).toBe(true);
  });

  it("returns pro resources for authenticated users", async () => {
    const ctx = createTestContext("user");
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.resources.getByAccessLevel("pro");
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("Products API", () => {
  it("returns all products", async () => {
    const ctx = createTestContext("user");
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.products.getAll();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("Portfolio API", () => {
  it("returns portfolio projects", async () => {
    const ctx = createTestContext("user");
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.portfolio.getAll();
    expect(Array.isArray(result)).toBe(true);
  });

  it("returns featured projects", async () => {
    const ctx = createTestContext("user");
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.portfolio.getFeatured();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("Testimonials API", () => {
  it("returns featured testimonials", async () => {
    const ctx = createTestContext("user");
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.testimonials.getFeatured();
    expect(Array.isArray(result)).toBe(true);
  });
});
