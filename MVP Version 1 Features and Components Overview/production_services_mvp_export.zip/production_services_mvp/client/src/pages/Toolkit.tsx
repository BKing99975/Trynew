import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Download, Zap } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const CHECKLIST_ITEMS = [
  "Lighting rig inventory and cable management",
  "Sound system setup and testing protocol",
  "Stage management communication plan",
  "Crew scheduling and assignments",
  "Safety protocols and emergency procedures",
  "Music cue sheet preparation",
  "Load-in and load-out timeline",
  "Contingency plans for technical failures",
  "Equipment backup and redundancy",
  "Post-show breakdown procedure",
];

export default function Toolkit() {
  const { user } = useAuth();
  const [showWizard, setShowWizard] = useState(false);
  const [checkedItems, setCheckedItems] = useState<Set<number>>(new Set());

  const readinessMutation = trpc.readiness.create.useMutation();

  const toggleItem = (index: number) => {
    const newChecked = new Set(checkedItems);
    if (newChecked.has(index)) {
      newChecked.delete(index);
    } else {
      newChecked.add(index);
    }
    setCheckedItems(newChecked);
  };

  const handleSaveResults = async () => {
    const score = Math.round((checkedItems.size / CHECKLIST_ITEMS.length) * 100);
    const checklist = CHECKLIST_ITEMS.map((item, idx) => ({
      item,
      completed: checkedItems.has(idx),
    }));

    try {
      await readinessMutation.mutateAsync({
        email: user?.email || "",
        checklist: JSON.stringify(checklist),
        score,
      });
      toast.success(`Results saved! Your readiness score: ${score}%`);
      setShowWizard(false);
      setCheckedItems(new Set());
    } catch (error) {
      toast.error("Failed to save results. Please try again.");
    }
  };

  const score = Math.round((checkedItems.size / CHECKLIST_ITEMS.length) * 100);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="py-20 md:py-32 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 neon-glow-pink">
              Production Toolkit
            </h1>
            <p className="text-lg leading-relaxed text-muted-foreground mb-8">
              Professional tools and templates to ensure your productions run flawlessly.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          {!showWizard ? (
            <div className="max-w-4xl mx-auto space-y-12">
              {/* Readiness Checker Card */}
              <Card className="p-8 border-border bg-gradient-to-br from-accent/10 to-transparent">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h2 className="text-3xl md:text-4xl font-bold mb-2 neon-glow-pink">
                      Production Readiness Checker
                    </h2>
                    <p className="text-lg leading-relaxed text-muted-foreground">
                      Comprehensive checklist to ensure you haven't missed anything before showtime.
                    </p>
                  </div>
                  <Zap className="h-8 w-8 text-accent flex-shrink-0" />
                </div>
                <Button
                  size="lg"
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                  onClick={() => setShowWizard(true)}
                >
                  Start Checker
                </Button>
              </Card>

              {/* Templates Section */}
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-8 neon-glow-pink">
                  Download Templates
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[
                    { name: "Lighting Plot Template", desc: "Professional lighting grid layout" },
                    { name: "Cue Sheet Template", desc: "Music and sound cue tracking" },
                    { name: "Stage Diagram Template", desc: "Set layout and positioning" },
                    { name: "Crew Schedule Template", desc: "Staff assignments and timing" },
                  ].map((template, idx) => (
                    <Card key={idx} className="p-6 border-border flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-lg mb-1">{template.name}</h3>
                        <p className="text-sm leading-relaxed text-muted-foreground">
                          {template.desc}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toast.info("Download coming soon")}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Wizard View */
            <div className="max-w-2xl mx-auto">
              <Card className="p-8 border-border">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl md:text-3xl font-bold">Readiness Checker</h2>
                  <div className="text-right">
                    <div className="text-4xl font-bold text-accent">{score}%</div>
                    <p className="text-sm leading-relaxed text-muted-foreground">Ready</p>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  {CHECKLIST_ITEMS.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-3 p-4 rounded-lg border border-border hover:border-accent transition-colors cursor-pointer"
                      onClick={() => toggleItem(idx)}
                    >
                      <div
                        className={`flex-shrink-0 w-6 h-6 rounded border-2 flex items-center justify-center transition-colors ${
                          checkedItems.has(idx)
                            ? "bg-accent border-accent"
                            : "border-border hover:border-accent"
                        }`}
                      >
                        {checkedItems.has(idx) && (
                          <CheckCircle2 className="h-4 w-4 text-accent-foreground" />
                        )}
                      </div>
                      <label className="flex-1 cursor-pointer text-sm leading-relaxed">
                        {item}
                      </label>
                    </div>
                  ))}
                </div>

                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowWizard(false);
                      setCheckedItems(new Set());
                    }}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  {user ? (
                    <Button
                      className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
                      onClick={handleSaveResults}
                      disabled={readinessMutation.isPending}
                    >
                      {readinessMutation.isPending ? "Saving..." : "Save Results"}
                    </Button>
                  ) : (
                    <Button
                      className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
                      onClick={() => toast.info("Please log in to save results")}
                    >
                      Save Results (Login Required)
                    </Button>
                  )}
                </div>
              </Card>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
