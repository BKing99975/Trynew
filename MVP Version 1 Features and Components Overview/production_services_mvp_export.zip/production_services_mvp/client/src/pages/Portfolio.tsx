import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Portfolio() {
  const projects = trpc.portfolio.getAll.useQuery();
  const testimonials = trpc.testimonials.getFeatured.useQuery();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="py-20 md:py-32 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 neon-glow-pink">
              Portfolio
            </h1>
            <p className="text-lg leading-relaxed text-muted-foreground mb-8">
              Explore a selection of productions I've directed technically, from intimate theater to large-scale events.
            </p>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 neon-glow-pink">Featured Projects</h2>
          {projects.data && projects.data.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.data.map((project) => (
                <Card
                  key={project.id}
                  className="border-border overflow-hidden transition-neon hover:border-accent group"
                >
                  {project.imageUrl && (
                    <div className="relative h-48 bg-muted overflow-hidden">
                      <img
                        src={project.imageUrl}
                        alt={project.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <div className="p-6">
                    <h3 className="text-lg md:text-xl font-bold mb-2">{project.title}</h3>
                    <p className="text-sm leading-relaxed text-muted-foreground mb-4">
                      {project.description}
                    </p>
                    <div className="space-y-2 mb-4">
                      {project.role && (
                        <div className="text-sm">
                          <span className="font-bold">Role:</span> {project.role}
                        </div>
                      )}
                      {project.venue && (
                        <div className="text-sm">
                          <span className="font-bold">Venue:</span> {project.venue}
                        </div>
                      )}
                    </div>
                    {project.highlights && (
                      <p className="text-xs leading-relaxed text-muted-foreground italic">
                        {project.highlights}
                      </p>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-lg leading-relaxed text-muted-foreground">
                Portfolio projects coming soon...
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Testimonials Section */}
      {testimonials.data && testimonials.data.length > 0 && (
        <section className="py-20 bg-card/50 border-t border-border">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center neon-glow-pink">
              What Clients Say
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {testimonials.data.map((testimonial) => (
                <Card key={testimonial.id} className="p-6 border-border">
                  {testimonial.rating && (
                    <div className="flex gap-1 mb-4">
                      {Array.from({ length: testimonial.rating }).map((_, i) => (
                        <Star
                          key={i}
                          className="h-4 w-4 fill-accent text-accent"
                        />
                      ))}
                    </div>
                  )}
                  <p className="text-sm leading-relaxed text-muted-foreground mb-4">
                    "{testimonial.content}"
                  </p>
                  <div>
                    <p className="font-bold text-sm">{testimonial.author}</p>
                    {testimonial.title && (
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        {testimonial.title}
                      </p>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
