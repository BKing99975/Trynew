import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lock, Download, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

const CATEGORIES = [
  { id: "lighting", label: "Lighting" },
  { id: "sound", label: "Sound" },
  { id: "stage_management", label: "Stage Management" },
  { id: "scheduling", label: "Scheduling" },
  { id: "safety", label: "Safety" },
  { id: "music_cues", label: "Music Cues" },
];

export default function Resources() {
  const { user, isAuthenticated } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Determine user's subscription tier from role
  const userRole = user?.role || "guest";
  const isPro = userRole === "pro" || userRole === "premium" || userRole === "admin";

  // Fetch resources
  const freeResources = trpc.resources.getByAccessLevel.useQuery("free");
  const proResources = isPro
    ? trpc.resources.getByAccessLevel.useQuery("pro")
    : { data: [] };

  const resources = [
    ...(freeResources.data || []),
    ...(proResources.data || []),
  ];

  const filtered = selectedCategory
    ? resources.filter((r) => r.category === selectedCategory)
    : resources;

  const isResourceLocked = (resource: any) => {
    return resource.accessLevel === "pro" && !isPro;
  };

  const handleDownload = (resource: any) => {
    if (isResourceLocked(resource)) {
      if (!isAuthenticated) {
        window.location.href = getLoginUrl();
      } else {
        toast.error("Upgrade to Pro to access this resource");
      }
      return;
    }

    if (resource.downloadUrl) {
      window.open(resource.downloadUrl, "_blank");
      toast.success("Download started");
    } else {
      toast.info("Download coming soon");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="py-20 md:py-32 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 neon-glow-pink">
              Production Resources
            </h1>
            <p className="text-lg leading-relaxed text-muted-foreground mb-8">
              Free guides, templates, and pro-level tools to elevate your productions.
            </p>
            {!isPro && (
              <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 mb-8">
                <p className="text-sm leading-relaxed text-muted-foreground mb-3">
                  Unlock all Pro resources with a subscription
                </p>
                <Button
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                  onClick={() => (window.location.href = "/pricing")}
                >
                  View Pricing <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-3 justify-center">
            <Button
              variant={selectedCategory === null ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
              className={
                selectedCategory === null
                  ? "bg-accent text-accent-foreground"
                  : ""
              }
            >
              All Resources
            </Button>
            {CATEGORIES.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat.id)}
                className={
                  selectedCategory === cat.id
                    ? "bg-accent text-accent-foreground"
                    : ""
                }
              >
                {cat.label}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Resources Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          {filtered.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((resource) => {
                const locked = isResourceLocked(resource);
                return (
                  <Card
                    key={resource.id}
                    className={`p-6 border-border flex flex-col ${
                      locked ? "opacity-75" : ""
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="text-lg font-bold flex-1 pr-2">
                        {resource.title}
                      </h3>
                      {locked && (
                        <Badge className="bg-accent/20 text-accent border border-accent/50 flex-shrink-0">
                          <Lock className="h-3 w-3 mr-1" />
                          LOCKED
                        </Badge>
                      )}
                      {resource.featured && !locked && (
                        <Badge className="bg-accent text-accent-foreground flex-shrink-0">
                          Featured
                        </Badge>
                      )}
                    </div>

                    <p className="text-sm leading-relaxed text-muted-foreground mb-4 flex-1">
                      {resource.description}
                    </p>

                    {locked && (
                      <p className="text-xs leading-relaxed text-muted-foreground mb-4 bg-accent/10 p-2 rounded border border-accent/20">
                        Included in Pro ($24.99/mo)
                      </p>
                    )}

                    <div className="flex gap-2">
                      {locked ? (
                        <Button
                          className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
                          onClick={() => handleDownload(resource)}
                        >
                          {isAuthenticated ? "Upgrade to Pro" : "Sign In"}
                        </Button>
                      ) : (
                        <Button
                          className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
                          onClick={() => handleDownload(resource)}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="p-12 border-border text-center">
              <p className="text-muted-foreground mb-4">
                No resources found in this category
              </p>
              <Button
                variant="outline"
                onClick={() => setSelectedCategory(null)}
              >
                View All Resources
              </Button>
            </Card>
          )}
        </div>
      </section>
    </div>
  );
}
