import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, Clock, MapPin } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const SERVICE_TYPES = [
  { id: "consultation", label: "Consultation", description: "1-hour strategy session" },
  { id: "workshop", label: "Workshop", description: "Half-day or full-day training" },
  { id: "on_site", label: "On-Site Assistance", description: "Technical direction for your event" },
];

export default function Booking() {
  const [selectedService, setSelectedService] = useState<"consultation" | "workshop" | "on_site" | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    description: "",
    eventDate: "",
  });

  const bookingMutation = trpc.bookings.create.useMutation();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService) {
      toast.error("Please select a service type");
      return;
    }

    try {
      await bookingMutation.mutateAsync({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        serviceType: selectedService,
        description: formData.description,
        eventDate: formData.eventDate ? new Date(formData.eventDate) : undefined,
      });
      toast.success("Booking request submitted! We'll contact you soon.");
      setFormData({ name: "", email: "", phone: "", description: "", eventDate: "" });
      setSelectedService(null);
    } catch (error) {
      toast.error("Failed to submit booking. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="py-20 md:py-32 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 neon-glow-pink">
              Book a Consultation
            </h1>
            <p className="text-lg leading-relaxed text-muted-foreground mb-8">
              Schedule time with me for consultations, workshops, or on-site technical direction for your productions.
            </p>
          </div>
        </div>
      </section>

      {/* Service Selection */}
      <section className="py-20 border-b border-border">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center neon-glow-pink">
            Select a Service
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {SERVICE_TYPES.map((service) => (
              <Card
                key={service.id}
                className={`p-6 border-2 cursor-pointer transition-neon ${
                  selectedService === service.id
                    ? "neon-border-pink border-accent"
                    : "border-border hover:border-accent"
                }`}
                onClick={() => setSelectedService(service.id as any)}
              >
                <h3 className="text-lg md:text-xl font-bold mb-2">{service.label}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {service.description}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-20">
        <div className="container mx-auto px-4 max-w-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold mb-2">Name *</label>
                <Input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your name"
                  required
                  className="bg-card border-border"
                />
              </div>
              <div>
                <label className="block text-sm font-bold mb-2">Email *</label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your@email.com"
                  required
                  className="bg-card border-border"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">Phone</label>
              <Input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+1 (555) 123-4567"
                className="bg-card border-border"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">Event Date (if applicable)</label>
              <Input
                type="datetime-local"
                name="eventDate"
                value={formData.eventDate}
                onChange={handleChange}
                className="bg-card border-border"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">Tell us about your project</label>
              <Textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Describe your production, venue, technical needs, and any specific questions..."
                rows={6}
                className="bg-card border-border"
              />
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
              disabled={bookingMutation.isPending || !selectedService}
            >
              {bookingMutation.isPending ? "Submitting..." : "Submit Booking Request"}
            </Button>
          </form>

          {/* Calendly Embed */}
          <div className="mt-20 pt-20 border-t border-border">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center neon-glow-pink">
              Or Schedule Directly
            </h2>
            <p className="text-center text-muted-foreground mb-8">
              Use Calendly below to schedule your consultation directly.
            </p>
            <div className="bg-card rounded-lg border border-border p-8 text-center">
              <p className="text-muted-foreground">
                Calendly embed will appear here. Configure your Calendly link in the admin panel.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
