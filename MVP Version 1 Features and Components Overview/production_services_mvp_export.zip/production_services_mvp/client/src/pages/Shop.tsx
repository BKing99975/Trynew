import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Shop() {
  const products = trpc.products.getAll.useQuery();

  const handleCheckout = (productId: number) => {
    toast.info("Stripe checkout integration coming soon");
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="py-20 md:py-32 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 neon-glow-pink">
              Digital Shop
            </h1>
            <p className="text-lg leading-relaxed text-muted-foreground mb-8">
              Download professional templates, lighting plots, cue sheets, and stage diagrams to streamline your productions.
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          {products.data && products.data.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.data.map((product) => (
                <Card
                  key={product.id}
                  className="p-6 border-border transition-neon hover:border-accent flex flex-col"
                >
                  <div className="flex-1 mb-6">
                    <h3 className="text-lg md:text-xl font-bold mb-2">{product.title}</h3>
                    <p className="text-sm leading-relaxed text-muted-foreground mb-4">
                      {product.description}
                    </p>
                    {product.featured && (
                      <Badge className="bg-accent text-accent-foreground mb-4">
                        Popular
                      </Badge>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-baseline justify-between">
                      <span className="text-3xl font-bold text-accent">
                        ${product.price}
                      </span>
                      <span className="text-xs text-muted-foreground">One-time purchase</span>
                    </div>

                    <Button
                      className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                      onClick={() => handleCheckout(product.id)}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Buy Now
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-lg leading-relaxed text-muted-foreground">
                Products coming soon...
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Info Section */}
      <section className="py-20 bg-card/50 border-t border-border">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center neon-glow-pink">
            Why Our Templates?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6 border-border">
              <h3 className="font-bold text-lg mb-2">Professional Quality</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Created by experienced technical directors for real-world productions.
              </p>
            </Card>
            <Card className="p-6 border-border">
              <h3 className="font-bold text-lg mb-2">Easy to Customize</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Fully editable templates that adapt to your specific production needs.
              </p>
            </Card>
            <Card className="p-6 border-border">
              <h3 className="font-bold text-lg mb-2">Instant Download</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                Get your files immediately after purchase, ready to use.
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
