ALTER TABLE `subscriptions` MODIFY COLUMN `status` enum('active','trialing','past_due','canceled','unpaid','none') DEFAULT 'none';--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('guest','free','pro','premium','admin') NOT NULL DEFAULT 'guest';--> statement-breakpoint
ALTER TABLE `subscriptions` ADD `stripeCustomerId` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `stripeCustomerId` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `subscriptionStatus` enum('active','trialing','past_due','canceled','unpaid','none') DEFAULT 'none';--> statement-breakpoint
ALTER TABLE `users` ADD `subscriptionTier` enum('free','pro','premium') DEFAULT 'free';--> statement-breakpoint
ALTER TABLE `users` ADD `currentPeriodEnd` timestamp;--> statement-breakpoint
ALTER TABLE `subscriptions` ADD CONSTRAINT `subscriptions_userId_unique` UNIQUE(`userId`);--> statement-breakpoint
ALTER TABLE `subscriptions` ADD CONSTRAINT `subscriptions_stripeSubscriptionId_unique` UNIQUE(`stripeSubscriptionId`);